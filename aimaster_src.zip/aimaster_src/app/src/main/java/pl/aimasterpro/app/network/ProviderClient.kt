package pl.aimasterpro.app.network

import org.json.JSONArray
import org.json.JSONObject
import pl.aimasterpro.app.core.ChatResponse
import pl.aimasterpro.app.core.ProviderConfig
import pl.aimasterpro.app.core.ProviderKind
import pl.aimasterpro.app.core.TokenUsageResult
import java.net.HttpURLConnection
import java.net.URL
import java.net.UnknownHostException
import java.net.SocketTimeoutException
import java.net.ConnectException
import java.io.IOException
import java.util.concurrent.ThreadLocalRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

class ProviderException(
    val httpCode: Int?,
    message: String,
    val responseBody: String = "",
    val category: String = "UNKNOWN"
) : Exception(message)

/** Synchronous transport with strict error classification, retry, and token usage extraction. */
data class ProviderModelInfo(
    val id: String,
    val name: String = id,
    val contextLength: Long? = null,
    val promptPricePerMillion: Double? = null,
    val completionPricePerMillion: Double? = null,
    /** true/false only when provider metadata is explicit; null means unknown. */
    val freeByPricing: Boolean? = null,
    val description: String = ""
)

class ProviderClient(
    private val connectTimeoutMs: Int = 15_000,
    private val readTimeoutMs: Int = 45_000
) {
    data class RequestScope internal constructor(val epoch: Long)

    private val cancellationEpoch = AtomicLong(0L)
    private val requestEpoch = ThreadLocal<Long>()
    private val activeConnections = ConcurrentHashMap<HttpURLConnection, Long>()
    private val unscopedEpoch = Long.MIN_VALUE

    /** Starts a fresh top-level chat scope. Every parallel agent must reuse this exact token. */
    fun beginRequestScope(): RequestScope {
        val newEpoch = cancellationEpoch.incrementAndGet()
        disconnectOlderScopes(newEpoch)
        return RequestScope(newEpoch)
    }

    /** Immediately disconnects in-flight HTTP calls and invalidates every call in the old scope. */
    fun cancelActiveRequests() {
        val newEpoch = cancellationEpoch.incrementAndGet()
        disconnectOlderScopes(newEpoch)
    }

    private fun disconnectOlderScopes(newEpoch: Long) {
        activeConnections.entries.toList().forEach { (connection, epoch) ->
            if (epoch != unscopedEpoch && epoch < newEpoch) runCatching { connection.disconnect() }
        }
    }

    private fun isCancelled(epoch: Long): Boolean =
        (epoch != unscopedEpoch && epoch != cancellationEpoch.get()) || Thread.currentThread().isInterrupted

    private fun cancelledException(): ProviderException =
        ProviderException(null, "Żądanie anulowane przez użytkownika.", category = "CANCELLED")

    private fun request(url: String, method: String, apiKey: String, body: JSONObject? = null, authHeader: String = "Authorization", extraHeaders: Map<String, String> = emptyMap()): JSONObject {
        val epoch = requestEpoch.get() ?: unscopedEpoch
        if (isCancelled(epoch)) throw cancelledException()
        val parsedUrl = URL(url)
        if (parsedUrl.protocol.equals("http", true)) {
            val host = parsedUrl.host.lowercase()
            val secondOctet = host.split(".").getOrNull(1)?.toIntOrNull()
            val privateHost = host == "localhost" || host.endsWith(".local") ||
                host.startsWith("127.") || host.startsWith("10.") || host.startsWith("192.168.") ||
                (host.startsWith("172.") && secondOctet != null && secondOctet in 16..31)
            val urlContainsCredential = parsedUrl.query?.contains("key=") == true
            if (!privateHost || apiKey.isNotBlank() || urlContainsCredential) {
                throw ProviderException(null, "Niezabezpieczone HTTP jest dozwolone wyłącznie dla lokalnego endpointu bez klucza API (np. Ollama w zaufanej sieci LAN). Użyj HTTPS dla usług zewnętrznych.", category = "SECURITY_HTTP")
            }
        }
        val conn = (parsedUrl.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = connectTimeoutMs.coerceAtLeast(1)
            readTimeout = readTimeoutMs.coerceAtLeast(1)
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Connection", "close")
            if (apiKey.isNotBlank()) setRequestProperty(authHeader, if (authHeader == "Authorization") "Bearer $apiKey" else apiKey)
            extraHeaders.forEach { (name, value) -> setRequestProperty(name, value) }
            if (body != null) { doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8") }
        }
        activeConnections[conn] = epoch
        if (isCancelled(epoch)) {
            activeConnections.remove(conn)
            conn.disconnect()
            throw cancelledException()
        }
        var phase = "CONNECT"
        try {
            if (isCancelled(epoch)) throw cancelledException()
            if (body != null) {
                phase = "WRITE_REQUEST"
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)); it.flush() }
            }
            if (isCancelled(epoch)) throw cancelledException()
            phase = "WAIT_RESPONSE"
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            phase = "READ_RESPONSE"
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (isCancelled(epoch)) throw cancelledException()

            if (code !in 200..299) {
                val category = when (code) {
                    400 -> "BAD_REQUEST"
                    401 -> "AUTH_UNAUTHORIZED"
                    403 -> "FORBIDDEN"
                    404 -> "ENDPOINT_NOT_FOUND"
                    408 -> "HTTP_REQUEST_TIMEOUT"
                    429 -> "RATE_LIMIT_QUOTA"
                    in 500..599 -> "SERVER_ERROR"
                    else -> "HTTP_ERROR"
                }
                throw ProviderException(code, "Dostawca zwrócił HTTP $code (${category}): ${text.take(200)}", text.take(2500), category = category)
            }
            if (text.isBlank()) throw ProviderException(code, "Dostawca zwrócił pustą odpowiedź HTTP $code.", category = "EMPTY_RESPONSE")
            return try { JSONObject(text) } catch (e: Exception) {
                throw ProviderException(code, "Nieprawidłowy JSON od dostawcy: ${e.message}", text.take(2500), category = "INVALID_RESPONSE")
            }
        } catch (e: ProviderException) {
            if (isCancelled(epoch)) throw cancelledException()
            throw e
        } catch (e: UnknownHostException) {
            if (isCancelled(epoch)) throw cancelledException()
            throw ProviderException(null, "DNS_ERROR podczas $phase dla hosta ${parsedUrl.host}: ${e.message ?: "UnknownHostException"}", category = "DNS_ERROR")
        } catch (e: SocketTimeoutException) {
            if (isCancelled(epoch)) throw cancelledException()
            val category = when (phase) {
                "CONNECT", "WRITE_REQUEST" -> "CONNECT_TIMEOUT"
                "WAIT_RESPONSE" -> "RESPONSE_TIMEOUT"
                else -> "READ_TIMEOUT"
            }
            throw ProviderException(null, "$category podczas $phase dla ${parsedUrl.host}: ${e.message ?: "SocketTimeoutException"}", category = category)
        } catch (e: ConnectException) {
            if (isCancelled(epoch)) throw cancelledException()
            throw ProviderException(null, "CONNECT_ERROR dla ${parsedUrl.host}: ${e.message ?: "ConnectException"}", category = "CONNECT_ERROR")
        } catch (e: IOException) {
            if (isCancelled(epoch)) throw cancelledException()
            throw ProviderException(null, "NETWORK_IO podczas $phase dla ${parsedUrl.host}: ${e.message ?: "IOException"}", category = "NETWORK_IO")
        } catch (e: Exception) {
            if (isCancelled(epoch)) throw cancelledException()
            throw ProviderException(null, "NETWORK_ERROR podczas $phase dla ${parsedUrl.host}: ${e.message ?: e.javaClass.simpleName}", category = "NETWORK_ERROR")
        } finally {
            activeConnections.remove(conn)
            conn.disconnect()
        }
    }

    /** Retry only failures that are safe to repeat. A POST is retried only if DNS/connection
     * failed before an HTTP connection could be established; read timeouts are never replayed. */
    private fun requestWithRetry(url: String, method: String, apiKey: String, body: JSONObject? = null, authHeader: String = "Authorization", extraHeaders: Map<String, String> = emptyMap()): JSONObject {
        val maxAttempts = 3
        val epoch = requestEpoch.get() ?: unscopedEpoch
        var lastException: ProviderException? = null
        for (attempt in 1..maxAttempts) {
            if (isCancelled(epoch)) throw cancelledException()
            try {
                return request(url, method, apiKey, body, authHeader, extraHeaders)
            } catch (e: ProviderException) {
                if (e.category == "CANCELLED" || isCancelled(epoch)) throw cancelledException()
                lastException = e
                val safeNetworkFailure = e.category in setOf("DNS_ERROR", "CONNECT_ERROR")
                val retryableRead = method.equals("GET", ignoreCase = true) &&
                    (e.category in setOf("CONNECT_TIMEOUT", "RESPONSE_TIMEOUT", "READ_TIMEOUT", "NETWORK_IO") ||
                     (e.httpCode != null && e.httpCode in 500..599))
                val retryable = retryableRead || (safeNetworkFailure && attempt < maxAttempts)
                if (!retryable || attempt >= maxAttempts) throw e
                val exponential = (350L * (1L shl (attempt - 1))).coerceAtMost(2_000L)
                val jitter = ThreadLocalRandom.current().nextLong(0L, 251L)
                if (isCancelled(epoch)) throw cancelledException()
                try { Thread.sleep(exponential + jitter) } catch (interrupted: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw ProviderException(null, "Przerwano oczekiwanie przed ponowieniem: ${e.message}", category = "INTERRUPTED")
                }
            }
        }
        throw lastException ?: ProviderException(null, "Nieznany błąd żądania sieciowego", category = "NETWORK_ERROR")
    }

    fun chat(config: ProviderConfig, systemPrompt: String, userText: String, attachmentMime: String = "", attachmentBase64: String = "",
             scope: RequestScope? = null): ChatResponse {
        val epoch = scope?.epoch ?: unscopedEpoch
        if (isCancelled(epoch)) throw cancelledException()
        requestEpoch.set(epoch)
        return try {
            if (isCancelled(epoch)) throw cancelledException()
            chatInternal(config, systemPrompt, userText, attachmentMime, attachmentBase64)
        } finally {
            requestEpoch.remove()
        }
    }

    private fun chatInternal(config: ProviderConfig, systemPrompt: String, userText: String, attachmentMime: String, attachmentBase64: String): ChatResponse = when (config.kind) {
        ProviderKind.ANTHROPIC -> {
            val root = config.baseUrl.trimEnd('/').ifBlank { "https://api.anthropic.com/v1" }
            val endpoint = if (root.endsWith("/messages")) root else "$root/messages"
            val contentBlocks = JSONArray().put(JSONObject().put("type", "text").put("text", userText))
            if (attachmentBase64.isNotBlank()) {
                when {
                    attachmentMime.startsWith("image/") -> contentBlocks.put(JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", attachmentMime).put("data", attachmentBase64)))
                    attachmentMime == "application/pdf" -> contentBlocks.put(JSONObject().put("type", "document").put("source", JSONObject().put("type", "base64").put("media_type", "application/pdf").put("data", attachmentBase64)))
                    else -> throw ProviderException(null, "Ten typ załącznika nie jest obsługiwany przez Anthropic.", category = "UNSUPPORTED_ATTACHMENT")
                }
            }
            val messages = JSONArray().put(JSONObject().put("role", "user").put("content", contentBlocks))
            val result = requestWithRetry(endpoint, "POST", config.apiKey,
                JSONObject().put("model", config.model).put("max_tokens", 4096).put("system", systemPrompt).put("messages", messages),
                authHeader = "x-api-key", extraHeaders = mapOf("anthropic-version" to "2023-06-01"))
            val content = result.optJSONArray("content") ?: JSONArray()
            val text = (0 until content.length()).mapNotNull { content.optJSONObject(it)?.takeIf { o -> o.optString("type") == "text" }?.optString("text") }.joinToString("\n")

            val usageObj = result.optJSONObject("usage")
            val input = usageObj?.optLong("input_tokens", -1L) ?: -1L
            val output = usageObj?.optLong("output_tokens", -1L) ?: -1L
            val cached = usageObj?.optLong("cache_read_input_tokens", 0L) ?: 0L
            val reasoning = 0L
            val finalInput = if (input >= 0) input else (systemPrompt.length + userText.length) / 4.toLong()
            val finalOutput = if (output >= 0) output else text.length / 4.toLong()
            val finalTotal = if (input >= 0 && output >= 0) input + output else finalInput + finalOutput
            val status = if (input >= 0 && output >= 0) "REAL" else "ESTIMATED"

            ChatResponse(text, TokenUsageResult(finalInput, finalOutput, finalTotal, reasoning, cached, status))
        }
        ProviderKind.OPENAI_COMPATIBLE -> {
            val root = config.baseUrl.trimEnd('/')
            val endpoint = if (root.endsWith("/chat/completions")) root else "$root/chat/completions"
            val userContent: Any = if (attachmentBase64.isBlank()) userText else {
                if (attachmentMime == "application/pdf") throw ProviderException(null, "Ten endpoint OpenAI-compatible nie otrzymuje PDF jako załącznika. Wybierz Gemini lub Anthropic albo wklej tekst z PDF.", category = "UNSUPPORTED_ATTACHMENT")
                if (!attachmentMime.startsWith("image/")) throw ProviderException(null, "Ten typ załącznika nie jest obsługiwany.", category = "UNSUPPORTED_ATTACHMENT")
                JSONArray().put(JSONObject().put("type", "text").put("text", userText))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:$attachmentMime;base64,$attachmentBase64")))
            }
            val messages = JSONArray()
                .put(JSONObject().put("role", "system").put("content", systemPrompt))
                .put(JSONObject().put("role", "user").put("content", userContent))
            val result = requestWithRetry(endpoint, "POST", config.apiKey,
                JSONObject().put("model", config.model).put("messages", messages))

            val choices = result.optJSONArray("choices") ?: throw ProviderException(null, "Dostawca zwrócił odpowiedź bez pola choices.", category = "INVALID_RESPONSE")
            val text = choices.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()

            val usageObj = result.optJSONObject("usage")
            val promptEval = result.optLong("prompt_eval_count", -1L)
            val evalCount = result.optLong("eval_count", -1L)

            val input = usageObj?.optLong("prompt_tokens", -1L)?.takeIf { it >= 0 } ?: if (promptEval >= 0) promptEval else -1L
            val output = usageObj?.optLong("completion_tokens", -1L)?.takeIf { it >= 0 } ?: if (evalCount >= 0) evalCount else -1L
            val total = usageObj?.optLong("total_tokens", -1L)?.takeIf { it >= 0 } ?: if (input >= 0 && output >= 0) input + output else -1L
            val cached = usageObj?.optJSONObject("prompt_tokens_details")?.optLong("cached_tokens", 0L) ?: 0L
            val reasoning = usageObj?.optJSONObject("completion_tokens_details")?.optLong("reasoning_tokens", 0L) ?: 0L

            val finalInput = if (input >= 0) input else (systemPrompt.length + userText.length) / 4.toLong()
            val finalOutput = if (output >= 0) output else text.length / 4.toLong()
            val finalTotal = if (total >= 0) total else finalInput + finalOutput
            val status = if (input >= 0 && output >= 0) "REAL" else "ESTIMATED"

            ChatResponse(text, TokenUsageResult(finalInput, finalOutput, finalTotal, reasoning, cached, status))
        }
        ProviderKind.GEMINI -> {
            val root = config.baseUrl.trimEnd('/')
            if (root.contains("/openai")) {
                // Official Google Gemini OpenAI-compatible endpoint: https://generativelanguage.googleapis.com/v1beta/openai/
                val endpoint = if (root.endsWith("/chat/completions")) root else "$root/chat/completions"
                val messages = JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", userText))
                val result = requestWithRetry(endpoint, "POST", config.apiKey,
                    JSONObject().put("model", config.model).put("messages", messages),
                    authHeader = "Authorization")
                val choices = result.optJSONArray("choices") ?: throw ProviderException(null, "Gemini OpenAI-compatible zwrócił brak pola choices.", category = "INVALID_RESPONSE")
                val text = choices.optJSONObject(0)?.optJSONObject("message")?.optString("content").orEmpty()

                val usageObj = result.optJSONObject("usage")
                val input = usageObj?.optLong("prompt_tokens", -1L) ?: -1L
                val output = usageObj?.optLong("completion_tokens", -1L) ?: -1L
                val reportedTotal = usageObj?.optLong("total_tokens", -1L) ?: -1L
                val finalInput = if (input >= 0L) input else (systemPrompt.length + userText.length) / 4L
                val finalOutput = if (output >= 0L) output else text.length / 4L
                // Never persist a negative total when a compatible endpoint omits usage metadata.
                // Negative totals are clamped out of budget accounting and would undercount usage.
                val finalTotal = if (reportedTotal >= 0L) reportedTotal else finalInput + finalOutput
                val status = if (input >= 0L && output >= 0L) "REAL" else "ESTIMATED"
                ChatResponse(text, TokenUsageResult(finalInput, finalOutput, finalTotal, 0L, 0L, status))
            } else {
                // Native Gemini REST API
                val encodedKey = java.net.URLEncoder.encode(config.apiKey, "UTF-8")
                val endpoint = "$root/models/${config.model}:generateContent?key=$encodedKey"
                val parts = JSONArray().put(JSONObject().put("text", "$systemPrompt\n\nUżytkownik: $userText"))
                if (attachmentBase64.isNotBlank()) {
                    if (!(attachmentMime.startsWith("image/") || attachmentMime == "application/pdf")) throw ProviderException(null, "Gemini: obsługiwane załączniki to obrazy i PDF.", category = "UNSUPPORTED_ATTACHMENT")
                    parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", attachmentMime).put("data", attachmentBase64)))
                }
                val result = requestWithRetry(endpoint, "POST", "", JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))))
                val text = result.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text").orEmpty()

                val meta = result.optJSONObject("usageMetadata")
                val input = meta?.optLong("promptTokenCount", -1L) ?: -1L
                val output = meta?.optLong("candidatesTokenCount", -1L) ?: -1L
                val total = meta?.optLong("totalTokenCount", -1L) ?: -1L
                val cached = meta?.optLong("cachedContentTokenCount", 0L) ?: 0L
                val reasoning = 0L

                val finalInput = if (input >= 0) input else (systemPrompt.length + userText.length) / 4.toLong()
                val finalOutput = if (output >= 0) output else text.length / 4.toLong()
                val finalTotal = if (total >= 0) total else finalInput + finalOutput
                val status = if (input >= 0 && output >= 0) "REAL" else "ESTIMATED"

                ChatResponse(text, TokenUsageResult(finalInput, finalOutput, finalTotal, reasoning, cached, status))
            }
        }
    }

    fun discoverModelDetails(config: ProviderConfig): List<ProviderModelInfo> = when (config.kind) {
        ProviderKind.ANTHROPIC -> {
            val root = config.baseUrl.trimEnd('/').ifBlank { "https://api.anthropic.com/v1" }
            val json = requestWithRetry("$root/models", "GET", config.apiKey, authHeader = "x-api-key", extraHeaders = mapOf("anthropic-version" to "2023-06-01"))
            val arr = json.optJSONArray("data") ?: JSONArray()
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                ProviderModelInfo(id, o.optString("display_name", id), o.optLong("context_length", -1L).takeIf { it > 0 })
            }.sortedBy { it.id }
        }
        ProviderKind.OPENAI_COMPATIBLE -> {
            val root = config.baseUrl.trimEnd('/').removeSuffix("/chat/completions")
            val json = requestWithRetry("$root/models", "GET", config.apiKey)
            val arr = json.optJSONArray("data") ?: JSONArray()
            val isOpenRouter = root.contains("openrouter.ai", true)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                val pricing = o.optJSONObject("pricing")
                val promptRaw = pricing?.optString("prompt")
                val completionRaw = pricing?.optString("completion")
                val prompt = promptRaw?.toDoubleOrNull()?.times(1_000_000.0)
                val completion = completionRaw?.toDoubleOrNull()?.times(1_000_000.0)
                val hasPricing = prompt != null && completion != null
                val explicitFree = id.equals("openrouter/free", true) || id.endsWith(":free", true)
                val free = if (isOpenRouter) {
                    when {
                        hasPricing && prompt == 0.0 && completion == 0.0 -> true
                        hasPricing -> false
                        explicitFree -> true
                        else -> null
                    }
                } else null
                ProviderModelInfo(
                    id = id,
                    name = o.optString("name", id),
                    contextLength = o.optLong("context_length", -1L).takeIf { it > 0 },
                    promptPricePerMillion = prompt,
                    completionPricePerMillion = completion,
                    freeByPricing = free,
                    description = o.optString("description", "")
                )
            }.sortedBy { it.id }
        }
        ProviderKind.GEMINI -> {
            val root = config.baseUrl.trimEnd('/').ifBlank { "https://generativelanguage.googleapis.com/v1beta" }
            if (root.contains("/openai")) {
                val json = requestWithRetry("$root/models", "GET", config.apiKey)
                val arr = json.optJSONArray("data") ?: JSONArray()
                (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    val id = o.optString("id").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    ProviderModelInfo(id, o.optString("name", id), o.optLong("context_length", -1L).takeIf { it > 0 })
                }.sortedBy { it.id }
            } else {
                val encodedKey = java.net.URLEncoder.encode(config.apiKey, "UTF-8")
                val json = requestWithRetry("$root/models?key=$encodedKey", "GET", "")
                val arr = json.optJSONArray("models") ?: JSONArray()
                (0 until arr.length()).mapNotNull { i ->
                    val o = arr.optJSONObject(i) ?: return@mapNotNull null
                    val id = o.optString("name").removePrefix("models/").takeIf { it.isNotBlank() } ?: return@mapNotNull null
                    ProviderModelInfo(id, o.optString("displayName", id), o.optLong("inputTokenLimit", -1L).takeIf { it > 0 }, description = o.optString("description", ""))
                }.sortedBy { it.id }
            }
        }
    }

    fun discoverModels(config: ProviderConfig): List<String> = discoverModelDetails(config).map { it.id }
}
