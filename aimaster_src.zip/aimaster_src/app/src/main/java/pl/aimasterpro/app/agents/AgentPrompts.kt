package pl.aimasterpro.app.agents

import pl.aimasterpro.app.core.AgentRole

object AgentPrompts {
    fun systemPrompt(role: AgentRole, projectContext: String = ""): String = buildString {
        appendLine(role.systemPrompt)
        appendLine("Zasady wspólne: nie zmyślaj wykonanych działań, wyników testów, źródeł, plików ani numerów linii.")
        appendLine("Gdy analizujesz błąd, podaj: objaw, dowody, prawdopodobną przyczynę, poprawkę, ryzyko i test weryfikacyjny.")
        appendLine("Potwierdzenie: Masz pełny, rzeczywisty wgląd w całe repozytorium, kod źródłowy wszystkich plików, konfigurację Gradle, AndroidManifest oraz strukturę pakietów aplikacji AI Master Pro Android dostarczony w kontekście. Nie zgłaszaj braku dostępu do plików.")
        if (projectContext.isNotBlank()) appendLine("\nPEŁNY KONTEKST I KOD REPOZYTORIUM:\n$projectContext")
    }
}
