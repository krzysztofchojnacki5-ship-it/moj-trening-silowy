package pl.aimasterpro.app.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.util.Locale

/** Local, privacy-safe model reliability history. No prompts, responses or API keys are stored. */
object ModelHealthTracker {
    private const val PREFS = "model_health_history_v1"
    private const val KEY = "events"
    private const val MAX_EVENTS = 300

    data class Event(
        val timestamp: Long,
        val providerId: String,
        val host: String,
        val model: String,
        val success: Boolean,
        val category: String,
        val latencyMs: Long
    )

    @Synchronized
    fun record(context: Context, provider: ProviderConfig, success: Boolean, category: String = "", latencyMs: Long = 0L) {
        val host = runCatching { URL(provider.baseUrl).host.lowercase(Locale.ROOT) }.getOrDefault(provider.baseUrl.lowercase(Locale.ROOT))
        val all = load(context).toMutableList()
        all.add(0, Event(System.currentTimeMillis(), provider.parentProviderId.ifBlank { provider.id }, host, provider.model, success, category, latencyMs.coerceAtLeast(0L)))
        val json = JSONArray()
        all.take(MAX_EVENTS).forEach { e ->
            json.put(JSONObject().put("ts", e.timestamp).put("provider", e.providerId).put("host", e.host)
                .put("model", e.model).put("ok", e.success).put("category", e.category).put("latency", e.latencyMs))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json.toString()).apply()
    }

    @Synchronized
    fun load(context: Context): List<Event> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Event(o.optLong("ts"), o.optString("provider"), o.optString("host"), o.optString("model"),
                    o.optBoolean("ok"), o.optString("category"), o.optLong("latency"))
            }
        }.getOrDefault(emptyList())
    }

    /** Keep the configured primary first unless recent evidence shows it is materially unhealthy. */
    fun rank(context: Context, configs: List<ProviderConfig>): List<ProviderConfig> {
        if (configs.size < 2) return configs
        val now = System.currentTimeMillis()
        val events = load(context).filter { now - it.timestamp <= 7L * 24 * 60 * 60 * 1000 }
        fun score(c: ProviderConfig): Int {
            val base = c.parentProviderId.ifBlank { c.id }
            val host = runCatching { URL(c.baseUrl).host.lowercase(Locale.ROOT) }.getOrDefault(c.baseUrl.lowercase(Locale.ROOT))
            val matching = events.filter { it.providerId.equals(base, true) && it.model.equals(c.model, true) && it.host == host }.take(30)
            var totalScore = 0
            matching.forEach { e ->
                totalScore += if (e.success) {
                    if (e.latencyMs >= 60_000L) 0 else if (e.latencyMs >= 30_000L) 1 else 2
                } else when (e.category.uppercase(Locale.ROOT)) {
                    "RATE_LIMIT_QUOTA", "RATE_LIMIT", "HTTP_429" -> -12
                    "DNS_ERROR", "CONNECT_ERROR" -> -10
                    "READ_TIMEOUT", "RESPONSE_TIMEOUT", "CONNECT_TIMEOUT" -> -6
                    else -> -5
                }
            }
            return totalScore
        }
        val primary = configs.first()
        val primaryScore = score(primary)
        val alternatives = configs.drop(1).sortedByDescending(::score)
        val bestAlternativeScore = alternatives.firstOrNull()?.let(::score) ?: Int.MIN_VALUE
        // A single transient DNS/connect error is not enough to demote a configured primary.
        // A 429 or repeated failures move it only when a configured backup has materially better history.
        return if (primaryScore <= -12 && bestAlternativeScore >= primaryScore + 5) alternatives + primary
        else listOf(primary) + alternatives
    }

    fun summary(context: Context): Map<String, List<Event>> = load(context)
        .groupBy { "${it.providerId} / ${it.model}" }
        .mapValues { (_, events) -> events.sortedByDescending { it.timestamp } }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
