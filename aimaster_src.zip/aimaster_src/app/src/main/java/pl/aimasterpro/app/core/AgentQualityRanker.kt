package pl.aimasterpro.app.core

/** Pure local ranker. It never calls a model and never changes provider/model assignments. */
object AgentQualityRanker {
    data class Evidence(val taskId: String, val rating: Int, val category: String = "")

    /**
     * Returns a smoothed quality score only after enough independent task IDs overall.
     * A well-populated category is scored independently. Sparse category evidence is
     * shrunk toward the agent's global score, preventing one or two ratings from making
     * a specialist look either perfect or unusable in a new domain.
     * Re-rating one task never increases sample size.
     */
    fun score(evidence: List<Evidence>, category: String = "", minSamples: Int = 5): Double? {
        require(minSamples >= 1)
        val unique = evidence.asSequence()
            .filter { it.taskId.isNotBlank() && (it.rating == 1 || it.rating == -1) }
            .distinctBy { it.taskId }
            .toList()
        if (unique.size < minSamples) return null

        fun smoothed(rows: List<Evidence>): Double =
            (rows.count { it.rating > 0 } + 2.0) / (rows.size + 4.0)

        val globalScore = smoothed(unique)
        if (category.isBlank()) return globalScore

        val scoped = unique.filter { it.category.equals(category, ignoreCase = true) }
        if (scoped.isEmpty()) return globalScore
        if (scoped.size >= minSamples) return smoothed(scoped)

        // Four pseudo-observations from the global record act as a conservative prior.
        // This is deterministic/local and only a tie-breaker in AgentRoutingPolicy.
        val priorWeight = 4.0
        val localPositive = scoped.count { it.rating > 0 }
        return (localPositive + priorWeight * globalScore) / (scoped.size + priorWeight)
    }
}
