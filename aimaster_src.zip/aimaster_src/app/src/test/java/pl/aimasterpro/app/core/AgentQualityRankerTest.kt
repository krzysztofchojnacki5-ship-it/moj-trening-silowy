package pl.aimasterpro.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentQualityRankerTest {
    @Test fun requiresFiveIndependentTasks() {
        val four = (1..4).map { AgentQualityRanker.Evidence("t$it", 1, "code") }
        assertNull(AgentQualityRanker.score(four, "code"))
        assertTrue(AgentQualityRanker.score(four + AgentQualityRanker.Evidence("t5", -1, "code"), "code")!! > 0.5)
    }

    @Test fun duplicateTaskIdsDoNotInflateEvidence() {
        val rows = (1..4).map { AgentQualityRanker.Evidence("t$it", 1, "code") } +
            AgentQualityRanker.Evidence("t1", -1, "code")
        assertNull(AgentQualityRanker.score(rows, "code"))
    }

    @Test fun usesCategoryEvidenceWhenItHasEnoughSamples() {
        val rows = (1..5).map { AgentQualityRanker.Evidence("code$it", 1, "code") } +
            (1..10).map { AgentQualityRanker.Evidence("other$it", -1, "other") }
        val score = AgentQualityRanker.score(rows, "code")!!
        assertEquals(7.0 / 9.0, score, 0.0001)
    }
    @Test fun sparseCategoryEvidenceIsShrunkTowardGlobalPerformance() {
        val rows = (1..10).map { AgentQualityRanker.Evidence("other-$it", 1, "other") } +
            AgentQualityRanker.Evidence("code-1", -1, "code")
        val global = AgentQualityRanker.score(rows)!!
        val category = AgentQualityRanker.score(rows, "code")!!
        assertTrue(category < global)
        assertTrue(category > 0.5)
    }

    @Test fun unknownCategoryUsesGlobalEvidenceWithoutExtraSamples() {
        val rows = (1..5).map { AgentQualityRanker.Evidence("task-$it", if (it <= 3) 1 else -1, "other") }
        assertEquals(AgentQualityRanker.score(rows)!!, AgentQualityRanker.score(rows, "unknown")!!, 0.0001)
    }

}
