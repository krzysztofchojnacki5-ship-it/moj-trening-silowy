package pl.aimasterpro.app.core

import org.junit.Assert.*
import org.junit.Test

class MasterResponseCheckTest {
    @Test fun flagsMissingStepsWhenUserAskedForProcedure() {
        val r = MasterResponseCheck.evaluate("Wyjaśnij krok po kroku jak wdrożyć zmianę", "To można zrobić przez konfigurację.")
        assertFalse(r.passed)
        assertTrue(r.warnings.any { it.contains("sekwencji kroków") })
    }
    @Test fun acceptsStructuredAnswer() {
        val r = MasterResponseCheck.evaluate("Podaj instrukcję krok po kroku", "1. Najpierw przygotuj projekt.\n2. Następnie uruchom testy.\n3. Na końcu sprawdź wynik.")
        assertTrue(r.passed)
    }
}
