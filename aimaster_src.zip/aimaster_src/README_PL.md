# AI Master Pro Android — v0.6.2

## Wersja 0.6.2 — kontrola rozbieżności i routing oparty na danych

- MASTER otrzymuje lokalny raport bezpośrednich rozbieżności liczbowych między specjalistami; konflikty bez dowodów są jawnie oznaczane, a nie arbitralnie rozstrzygane.
- Wykrywanie konfliktów jest deterministyczne i nie zużywa tokenów API.
- Niezawodność operacyjna agentów (ukończenie niezależnych zadań) jest dodatkowym, słabym tie-breakerem; nie jest mylona z jakością merytoryczną.
- Wskaźnik operacyjny wymaga 8 niezależnych zadań i jest wygładzany.
- Bez zmian w kluczach, profilach providerów, historii czatów i backupach.
- Pełny build Android/JUnit nie został potwierdzony w środowisku przygotowania; szczegóły w `BUILD_STATUS_0.6.2_PL.md`.

Szczegóły: `CHANGELOG_0.6.2_CONFLICT_AWARE_ROUTING_PL.md`.

---

## Wersja 0.6.1 — bezpieczeństwo pamięci wyników

- Cache rozróżnia dostawcę, bazowy URL API i model; raport z fallbacku nie zatruwa cache przypisanego profilu.
- Fingerprint używa kodowania pól z długością i wersji `task-cache-v2`.
- Rezerwa syntezy jest liczona według liczby agentów po adaptacyjnym ograniczeniu.
- Pełny build Android/JUnit nie został potwierdzony; zobacz `BUILD_STATUS_0.6.1_PL.md`.

Szczegóły: `CHANGELOG_0.6.1_CACHE_SAFETY_PL.md`.

---

## Wersja 0.6.0 — adaptacyjny silnik MASTER-a

- Cache raportów agentów: ścisły fingerprint wejścia, załączników, kontekstu i modelu; TTL 72 h; tylko udane raporty; cache hit nie zużywa tokenów API.
- Samokontrola MASTER-a: lokalne testy struktury odpowiedzi, ostrzeżenia bez dodatkowego wywołania modelu.
- Adaptacyjny budżet: dynamiczna liczba specjalistów, limit raportów i rezerwa syntezy zależne od trudności.
- Bez nowych zależności, uprawnień ani zmian konfiguracji providerów.
- Pełny build Android wymaga ponownej weryfikacji w środowisku z Gradle 8.13 i Android SDK; szczegóły w `BUILD_STATUS_0.6.0_PL.md`.

Szczegóły: `CHANGELOG_0.6.0_ADAPTIVE_MASTER_ENGINE_PL.md`.

---

## Wersja 0.5.1 — poprawki nawigacji czatu, rankingu i czytelności odpowiedzi

- Działania w dedykowanym czacie Asystenta Kodu pozostają w tym czacie; ocena odpowiedzi i usunięcie załącznika nie przenoszą do MASTER-a.
- Ranking agentów uwzględnia wyłącznie oceny raportów agentów. Oceny końcowej odpowiedzi i MASTER-a są rozdzielone w analizie i rankingu modeli.
- Nieliczne oceny w konkretnej kategorii są ostrożnie wygładzane względem globalnej skuteczności agenta, zamiast dawać skrajny wynik.
- Renderer czatu obsługuje klikalne linki Markdown HTTP/HTTPS.
- Pełny build Android nie został potwierdzony w środowisku przygotowania; zobacz `BUILD_STATUS_0.5.1_PL.md`.

Szczegóły: `CHANGELOG_0.5.1_CHAT_QUALITY_REFINEMENTS_PL.md`.

## Wersja 0.5.0 — uczenie agentów, czat i niezawodne Stop

- Lokalny feedback poprawia kolejność agentów wyłącznie przy remisie dopasowania słów kluczowych; próg 5 niezależnych zadań, bez dodatkowych tokenów.
- Każda odpowiedź w czacie ma własne metadane provider/model/czas i własne przyciski 👍/👎.
- Zachowano identyfikatory odpowiedzi również w starszych rozmowach bez metadanych.
- Dedykowany wątek Asystenta Kodu pozostaje aktywny po wysłaniu wiadomości, ma własny selektor modelu i nowy czat bez naruszania historii MASTER-a.
- Stop rozłącza aktywne HTTP POST, przerywa batch agentów i blokuje spóźnione wywołania.
- Tokeny, logi agentów i metadane są przypisane do konkretnego żądania i rozmowy.
- Pełny build Android nie został potwierdzony w środowisku przygotowania; zobacz `BUILD_STATUS_0.5.0_PL.md`.

Szczegóły: `CHANGELOG_0.5.0_CHAT_ROUTING_CANCELLATION_PL.md`.

---

# AI Master Pro Android — v0.3.9

## Nowości v0.1.3
- Wybrany dostawca/model czatu jest zapamiętywany po ponownym uruchomieniu.
- Historia aktualnego wątku czatu jest zapisywana lokalnie i odtwarzana po starcie aplikacji.
- Odpowiedzi i wiadomości można zaznaczać; wykryte adresy WWW i e-maile są klikalne; odpowiedzi można kopiować.
- Dodano selektor załączników dla plików tekstowych, logów, JSON, XML, Markdown, CSV i kodu. Zawartość pliku jest dołączana do następnej wiadomości (limit 120 000 znaków).
- Zakładka Agenci pokazuje odpowiedzialności, pozwala wybrać rolę do czatu i prezentuje lokalny dziennik rozpoczętych zadań/odpowiedzi.
- Wybór modelu jest odróżniony od testu połączenia; aplikacja informuje, że samo wybranie modelu nie potwierdza działania API.

## Ograniczenia v0.1.3
- Historia to na razie jeden lokalny wątek, nie lista wielu nazwanych rozmów. „Nowy czat” czyści ten wątek i ostrzega wcześniej.
- Załączniki obrazów, PDF i plików binarnych nie są jeszcze wysyłane do modeli. Obecna obsługa dotyczy tekstu/kodu/logów.
- Linki otrzymane w odpowiedziach są klikalne, ale aplikacja nie ma własnej przeglądarki ani pobierania linków.
- Dziennik agentów nie jest pełną historią komunikacji agent-agent. Równoległa orkiestracja agentów nadal nie jest wdrożona.
- Pełne renderowanie Markdown (np. tabele i bloki kodu z kolorowaniem) pozostaje do rozbudowy.

## Co zawiera ta wersja
- Profile dostawców dodawane automatycznie przy pierwszym uruchomieniu: Google Gemini, OpenAI, Anthropic, Groq, OpenRouter, Mistral, Perplexity, lokalny Ollama (wymaga wpisania adresu komputera) oraz własny endpoint.
- Profile startują z pustymi kluczami API. Użytkownik wpisuje własne klucze w ustawieniach; żadne klucze z przykładowej bazy nie są dołączane do projektu.
- Osobny adapter Gemini, OpenAI-compatible i Anthropic Messages API.
- Funkcja „Wczytaj bazę / starą kopię bez hasła” rozpoznaje starszy JSON `ai_master_pro_backup` i migruje profile lokalnie. Stare pola kluczy, które wyglądają na nieprzezroczysty szyfrogram, są pomijane — taki klucz trzeba wprowadzić ponownie.
- Eksport nowej bazy nadal jest szyfrowany hasłem.

## Ważne o modelach
Nazwy startowe to propozycje profili, nie gwarancja dostępu ani darmowego użycia. Po dodaniu własnego klucza użyj „Pobierz listę modeli” i wybierz ID zwrócone przez konkretne API. Limity i ceny zależą od dostawcy i konta. OpenRouter używa `openrouter/free` jako routingu do dostępnego modelu bezpłatnego, jeśli ten routing jest dostępny dla konta.

## Bezpieczeństwo
- Nie umieszczaj prawdziwych kluczy w repozytorium ani w zgłoszeniach błędów.
- Klucze w aplikacji przechowywane są przez `SecureStore` przy użyciu Android Keystore.
- Import starej kopii odbywa się na urządzeniu; aplikacja nie wysyła pliku kopii do serwera.
- Dla lokalnego Ollama nie używaj `localhost` w telefonie. Wpisz osiągalny z telefonu adres komputera w sieci lokalnej i świadomie skonfiguruj dostęp HTTP.

## Otwieranie
1. Rozpakuj ZIP.
2. Otwórz w Android Studio folder zawierający `settings.gradle.kts`.
3. Użyj JDK 17 i pozwól Gradle pobrać zależności.
4. Uruchom `Build > Make Project`, następnie zbuduj APK.

W tym środowisku nie przeprowadzono kompilacji Androida, więc przed użyciem trzeba wykonać synchronizację i kompilację w Android Studio.


## Wersja 0.1.4 — rozmowy, załączniki i orkiestracja

Wersja 0.1.4 zapisuje wiele rozmów lokalnie i pozwala wracać do nich przez przycisk „Historia”. Nowy czat nie usuwa poprzednich rozmów. Można dodawać pliki tekstowe/kod/logi, obrazy oraz PDF (limit 12 MB). Obrazy są przekazywane do modeli multimodalnych Gemini, Anthropic i zgodnych endpointów OpenAI-compatible. PDF jest przekazywany do Gemini i Anthropic; ogólne endpointy OpenAI-compatible nie mają wspólnego formatu PDF, więc aplikacja pokaże komunikat o ograniczeniu.

Po wybraniu MASTER uruchamiana jest sekwencyjna współpraca ról Badacz, Programista i Recenzent, po czym MASTER scala wyniki. To pierwsza wersja orkiestracji, nie praca równoległa. Kompilację APK należy sprawdzić w Android Studio.


## Wersja 0.1.5 — przypisanie modeli agentom i kontrolki połączenia
W zakładce „Agenci” można przypisać osobnego dostawcę/model do każdej roli. Kontrolka jest szara, gdy połączenia nie sprawdzono, pomarańczowa podczas testu, zielona po udanym rzeczywistym wywołaniu API i czerwona po błędzie. MASTER deleguje sekwencyjnie do Badacza, Programisty i Recenzenta; te role mogą korzystać z różnych konfiguracji. Każdy agent wymaga własnej kompletnej konfiguracji, jeśli ma uczestniczyć w delegacji. Test kompilacji w tym środowisku nie został ukończony z powodu braku dostępu do serwera dystrybucji Gradle.


## Wersja 0.2.0 — fuzja architektury Multi-Agent
- Dodano 67 profili specjalistycznych na podstawie publicznego katalogu forka OpenCode autora.
- MASTER wybiera do 4 specjalistów i uruchamia ich równolegle (maksymalnie 4 jednoczesne wywołania).
- Agenci w jednym batchu korzystają domyślnie z jednego dostawcy/modelu MASTER-a; nie potrzeba osobnych kluczy API dla każdego profilu.
- Dodano trzy tryby pracy zapisywane dla każdej rozmowy: Planowanie, Diagnostyka i Automat.
- Dodano walidację ID zadań i deklarowanych zakresów; niezależne zadania są rozdzielane na osobne wywołania modelu.
- Dodano możliwość korzystania z lokalnego Ollama bez klucza API, z ograniczeniem HTTP do prywatnych adresów bez klucza.
- Zmieniono wrapper Gradle na 8.13 dla zgodności z AGP 8.13.2.

### Ważne ograniczenia
To jest fuzja architektury agentowej z aplikacją Android, nie pełna implementacja środowiska programistycznego OpenCode. Aplikacja wykonuje równoległe wywołania modeli i scala raporty, ale nie ma jeszcze dostępu do repozytorium, terminala ani narzędzi modyfikujących pliki. Tryb Automat nie oznacza jeszcze samodzielnej edycji projektu. Router wybiera specjalistów na podstawie słów kluczowych, a nie zaawansowanej klasyfikacji semantycznej.

Nazwy i zakresy 67 ról pochodzą z publicznego katalogu autora; pełne, oryginalne pliki promptów nie zostały skopiowane do tej paczki. Nie należy utożsamiać profili odtworzonych w Kotlinie z dosłownymi promptami autora.

### Koszty
Same profile agentów są bezpłatne. Wspólny model oznacza brak konieczności posiadania 67 kluczy API. Koszt wywołań zależy jednak od wybranego modelu i dostawcy. Ollama może działać bez opłat za API na własnym sprzęcie.

### Uruchomienie i weryfikacja
Otwórz folder z `settings.gradle.kts` w Android Studio, użyj JDK 17, wykonaj synchronizację Gradle i `Build > Make Project`. W tym środowisku nie było możliwe przeprowadzenie kompilacji (brak Gradle/Android SDK i blokada pobrania dystrybucji). Raport szczegółowy: `docs/FUSION_IMPLEMENTATION_REPORT_PL.md`.


## Wersja 0.2.1 — katalog modeli i profile agentów

- Zakładka MODELE pobiera aktualne identyfikatory modeli z API skonfigurowanych dostawców.
- Katalog obsługuje wyszukiwanie, filtrowanie po darmowości/cenie, kopiowanie ID, test modelu i tworzenie profilu.
- Dane cenowe OpenRouter są pobierane z metadanych `pricing`; brak danych oznacza „cena nieznana”, nigdy automatycznie FREE.
- Profile modeli dziedziczą klucz i endpoint z profilu bazowego dostawcy.
- Zakładka AGENTY służy do przypisywania profili do ról i testowania ich połączenia.
- Failover jest ograniczony do modeli z potwierdzonym darmowym dostępem; błędy 401/403 nie uruchamiają przełączenia.


## Routing oszczędzający tokeny (0.2.2)

MASTER najpierw klasyfikuje wiadomość lokalnie, bez dodatkowego wywołania modelu. Zwykła rozmowa i pytania ogólne trafiają bezpośrednio do MASTER-a. Zadanie specjalistyczne domyślnie uruchamia jednego agenta. Zespół jest uruchamiany tylko dla rozpoznanego zadania wieloetapowego/wielodziedzinowego albo na jawne polecenie użytkownika. Sam załącznik nie uruchamia podagentów. Szczegóły i ograniczenia opisuje `CHANGELOG_0.2.2_PL.md`.


## Wersja 0.3.0 — lokalny silnik agentów i ochrona kosztów

- MASTER nie uruchamia specjalistów przy powitaniu ani zwykłym pytaniu.
- Automatyczne zadania wykorzystują jednego specjalistę; zadania wielodziedzinowe do trzech; czterech tylko po jawnej prośbie użytkownika.
- Profile modeli specjalistów są mapowane na przypisania ról i walidowane przed użyciem.
- Płatne lub niezweryfikowane modele są pomijane w domyślnej ścieżce czatu; brak darmowego profilu zatrzymuje żądanie zamiast wysłać je do modelu płatnego.
- Zużycie tokenów jest przypisywane do faktycznego dostawcy/modelu specjalisty.
- Żądania generowania POST nie są automatycznie ponawiane po niejednoznacznym błędzie sieci.
- Silnik działa w aplikacji Android; nie wymaga stale uruchomionego komputera ani własnego serwera.
- Pełna kompilacja Androida i testy Gradle muszą zostać wykonane w Android Studio; środowisko przygotowania paczki nie miało dostępu do pobrania Gradle 8.13.


## Wersja 0.3.9 — mniej tokenów, lepsza synteza i pamięć kontekstowa

- Pamięć wspólna jest wybierana lokalnie według słów kluczowych bieżącego zadania; do promptu trafia ograniczona liczba reguł i maksymalnie 2 400 znaków.
- Operacyjne statystyki agentów nie są automatycznie dopisywane do każdego promptu. Można je dołączyć jawnie, ale standardowo pozostają w lokalnym dzienniku i analizie jakości.
- Kontekst dla agentów ma limit 1 800 znaków; ogranicza to wielokrotne przesyłanie tych samych reguł w równoległym batchu.
- MASTER otrzymuje do syntezy wyłącznie niepuste, poprawnie zakończone raporty. Błędy API i blokady nie są wstrzykiwane jako treść merytoryczna.
- Raporty są sprawiedliwie skracane do 6 000 znaków na raport i 18 000 znaków łącznie.
- Rezerwa budżetu uwzględnia oszacowany kontekst raportów syntezy, pamięć i prompt użytkownika.
- Dodano testy dla selekcji pamięci, limitów kontekstu i filtrowania raportów.

### Weryfikacja 0.3.9
Pełny build Android/Gradle nie został potwierdzony w środowisku przygotowania. Przed instalacją wykonaj synchronizację Gradle i `Build > Make Project` w Android Studio z JDK 17.
